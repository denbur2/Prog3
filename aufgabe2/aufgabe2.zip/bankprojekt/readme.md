Bei der letzten bewertung meinten sie ich solle nur die quelltexte abgeben meinten sie damit dass sie keine ordnerstruktur wollen oder das nur .java datein existieren sollen?
Wollen sie dann noch eine überarbeitete version von aufgabe1 haben?
